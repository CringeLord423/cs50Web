x = [{"a":1}]

print(len(x))